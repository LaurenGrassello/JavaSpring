package com.laurenodalen.ninjagold.controller;

import java.util.*;
import java.text.SimpleDateFormat;
import org.springframework.ui.Model;
import javax.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class NinjaController {

	@GetMapping("/")
	public String index() {
		return "index.jsp";
	}

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/gold", method = { RequestMethod.GET, RequestMethod.POST }) //includes both get and post
	public String index(HttpSession session, Model model, 
			@RequestParam(value = "farm", required = false) String farm,
			@RequestParam(value = "cave", required = false) String cave,
			@RequestParam(value = "house", required = false) String house,
			@RequestParam(value = "quest", required = false) String quest,
			@RequestParam(value = "reset", required = false) String reset,
			@RequestParam(value = "spa", required = false) String spa
			){

		Integer gold = 0; //set gold to zero
		ArrayList<String> activities = new ArrayList<>(); //list of gold earned/taken
		SimpleDateFormat format = new SimpleDateFormat("MMMM d Y h:mm a"); //used for time stamps

		//used to show list of activities -- gold earned/taken
		if (session.getAttribute("gold") == null) {
			session.setAttribute("gold", 0);
			session.setAttribute("activities", activities);
		} else {
			gold = (Integer) session.getAttribute("gold");
			activities = (ArrayList<String>) session.getAttribute("activities");
			session.setAttribute("actions", activities);
		}

		//random gold earned with farm
		if (farm != null) {
			Integer total = new Random().nextInt(11) + 10;
			gold += total;

			session.setAttribute("gold", gold);
			activities.add(0, "You entered a farm and earned " + total + " gold. (" + format.format(new Date()) + ")");

			return "redirect:/gold";
		}
		
		//random gold earned with cave
		if (cave != null) {
			Integer total = new Random().nextInt(11) + 10;
			gold += total;

			session.setAttribute("gold", gold);
			activities.add(0, "You entered a cave and earned " + total + " gold. (" + format.format(new Date()) + ")");

			return "redirect:/gold";
		}

		//random gold earned with house
		if (house != null) {
			Integer total = new Random().nextInt(11) + 10;
			gold += total;

			session.setAttribute("gold", gold);
			activities.add(0, "You entered a house and earned " + total + " gold. (" + format.format(new Date()) + ")");

			return "redirect:/gold";
		}
		
		//random gold earned/taken with quest
		if (quest != null) {
			Integer total = new Random().nextInt(101) - 50;
			gold += total;

			session.setAttribute("gold", gold);
			if (total < 0) {
				activities.add(0, "You failed the quest and lost " + (total * -1) + " gold. Ouch! (" + format.format(new Date())
						+ ")");
			} else {
				activities.add(0,
						"You completed the quest and earned " + total + " gold. (" + format.format(new Date()) + ")");
			}

			return "redirect:/gold";
		}
		
		//bonus spa
		if (spa != null) {
			Integer total = new Random().nextInt(5, 21);
			gold -= total;

			session.setAttribute("gold", gold);
			activities.add(0, "You entered the spa and lost " + (total * -1) + " gold. (" + format.format(new Date()) + ")");

			return "redirect:/gold";
		}

		//bonus reset gold count
		if (reset != null) {
			gold = 0;
			session.invalidate();
			return "redirect:/gold";
		}
		
		return "index.jsp";
	}

}