package com.laurenodalen.counter.controller;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;


@Controller
public class Counter {
	private int count = 0;
	
	public Counter() {
		
	}
	public int getCount() {
		return count;
	}
	
	public void setCount(int count) {
		this.count = count;
	}
	
	public int resetCount() {
		return count = 0;
	}
	
	@GetMapping("/your_server")
	public String index(HttpSession session) {
		int currCount = getCount();
		currCount++;
		setCount(currCount);
		session.setAttribute("count", currCount);
		return "index.jsp";
	}

	@GetMapping("/your_server/counter")
	public String counter(HttpSession session, Model model) {
		Integer counts = (Integer) session.getAttribute("count");
		if (counts == null) {
			counts = 0;
		}
		model.addAttribute("count", counts);
		return "counter.jsp";
	}
	
	@GetMapping("/your_server/counter/reset")
	public String reset(HttpSession session, Model model) {
		Integer counts = (Integer) session.getAttribute("count");
		int currCount = resetCount();
		setCount(currCount);
		model.addAttribute("count", currCount);
		return "counter.jsp";
	}
	
	@GetMapping("/your_server/counter/two")
	public String plusTwo(HttpSession session) {
		int currCount = getCount();
		currCount+=2;
		setCount(currCount);
		session.setAttribute("count", currCount);
		return "countTwo.jsp";
	}
}
