package com.laurenodalen.counter.model;

public class CounterModel {
	private int count = 0;
	
	public CounterModel() {
		
	}
	public int getCount() {
		return count;
	}
	
	public void setCount(int count) {
		this.count = count;
	}
}
